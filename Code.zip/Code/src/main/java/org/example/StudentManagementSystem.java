package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StudentManagementSystem {
    private static List<Student> students = new ArrayList<>();
    private static JTextField txtFirstName, txtLastName;
    private static JTextArea txtAreaDanhSach;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Student Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        // Initialize components
        txtFirstName = new JTextField(10);
        txtLastName = new JTextField(10);
        txtAreaDanhSach = new JTextArea(10, 30);
        txtAreaDanhSach.setEditable(false);

        // Add components to frame
        frame.add(new JLabel("First Name:"));
        frame.add(txtFirstName);
        frame.add(new JLabel("Last Name:"));
        frame.add(txtLastName);
        frame.add(new JScrollPane(txtAreaDanhSach));

        // Button "Add Student"
        JButton btnThem = new JButton("Add Student");
        btnThem.addActionListener(e -> addStudent());
        frame.add(btnThem);

        // Button "Find by Last Name"
        JButton btnFindLastName = new JButton("Find by Last Name");
        btnFindLastName.addActionListener(e -> findByLastName());
        frame.add(btnFindLastName);

        // Button "Find and Edit by Full Name"
        JButton btnEditFullName = new JButton("Edit by Full Name");
        btnEditFullName.addActionListener(e -> editByFullName());
        frame.add(btnEditFullName);

        // Load previous students from file
        loadStudentsFromFile();

        // Set up frame
        frame.pack();
        frame.setVisible(true);
    }

    // Method to add a student
    private static void addStudent() {
        String firstName = txtFirstName.getText();
        String lastName = txtLastName.getText();
        Student student = new Student(firstName, lastName);
        students.add(student);
        displayStudents();
        saveStudentsToFile();
    }

    // Method to find students by last name
    private static void findByLastName() {
        String lastName = txtLastName.getText();
        StringBuilder sb = new StringBuilder();
        for (Student student : students) {
            if (student.getLastName().equalsIgnoreCase(lastName)) {
                sb.append(student.toString()).append("\n");
            }
        }
        txtAreaDanhSach.setText(sb.length() > 0 ? sb.toString() : "No students found with that last name.");
    }

    // Method to find and edit a student by full name
    private static void editByFullName() {
        String fullName = txtFirstName.getText() + " " + txtLastName.getText();
        for (Student student : students) {
            if (student.toString().equalsIgnoreCase(fullName)) {
                String newFirstName = JOptionPane.showInputDialog("Enter new first name:", student.getFirstName());
                String newLastName = JOptionPane.showInputDialog("Enter new last name:", student.getLastName());
                student.setFirstName(newFirstName);
                student.setLastName(newLastName);
                displayStudents();
                saveStudentsToFile();
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "No student found with that full name.");
    }

    // Method to display the list of students in JTextArea
    private static void displayStudents() {
        StringBuilder sb = new StringBuilder();
        for (Student student : students) {
            sb.append(student.toString()).append("\n");
        }
        txtAreaDanhSach.setText(sb.toString());
    }

    // Method to save the list of students to a file
    private static void saveStudentsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.dat"))) {
            oos.writeObject(students);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to read the list of students from a file
    private static void loadStudentsFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.dat"))) {
            students = (List<Student>) ois.readObject();
            displayStudents();
        } catch (FileNotFoundException e) {
            // File not found, no action needed
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Inner class for Student
    static class Student implements Serializable {
        private String firstName;
        private String lastName;

        public Student(String firstName, String lastName) {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        @Override
        public String toString() {
            return firstName + " " + lastName;
        }
    }
}
