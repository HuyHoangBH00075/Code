package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StudentManagementSystem {
    private static List<Student> students = new ArrayList<>();
    private static JTextField txtMaSV, txtTenSV;
    private static JTextArea txtAreaDanhSach;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Student Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        // Initialize components
        txtMaSV = new JTextField(10);
        txtTenSV = new JTextField(10);
        txtAreaDanhSach = new JTextArea(10, 30);
        txtAreaDanhSach.setEditable(false);

        // Add components to frame
        frame.add(new JLabel("Student ID:"));
        frame.add(txtMaSV);
        frame.add(new JLabel("Student Name:"));
        frame.add(txtTenSV);
        frame.add(new JScrollPane(txtAreaDanhSach));

        // Button "Add Student"
        JButton btnThem = new JButton("Add Student");
        btnThem.addActionListener(e -> addStudent());
        frame.add(btnThem);

        // Button "Update Student"
        JButton btnCapNhat = new JButton("Update Student");
        btnCapNhat.addActionListener(e -> updateStudent());
        frame.add(btnCapNhat);

        // Button "Delete Student"
        JButton btnXoa = new JButton("Delete Student");
        btnXoa.addActionListener(e -> deleteStudent());
        frame.add(btnXoa);

        // Button "Show Students"
        JButton btnHienThi = new JButton("Show Students");
        btnHienThi.addActionListener(e -> hienThiDanhSach());
        frame.add(btnHienThi);

        // Load previous students from file
        docDanhSachTuFile();

        // Set up frame
        frame.pack();
        frame.setVisible(true);
    }

    // Method to add a student
    private static void addStudent() {
        try {
            int maSV = Integer.parseInt(txtMaSV.getText());
            String tenSV = txtTenSV.getText();
            Student student = new Student(maSV, tenSV);
            students.add(student);
            hienThiDanhSach();
            luuDanhSachVaoFile();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid Student ID. Please enter a number.");
        }
    }

    // Method to update a student
    private static void updateStudent() {
        try {
            int maSV = Integer.parseInt(txtMaSV.getText());
            String tenSV = txtTenSV.getText();
            for (Student student : students) {
                if (student.getMaSV() == maSV) {
                    student.setTenSV(tenSV);
                    hienThiDanhSach();
                    luuDanhSachVaoFile();
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Student not found.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid Student ID. Please enter a number.");
        }
    }

    // Method to delete a student
    private static void deleteStudent() {
        try {
            int maSV = Integer.parseInt(txtMaSV.getText());
            students.removeIf(student -> student.getMaSV() == maSV);
            hienThiDanhSach();
            luuDanhSachVaoFile();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid Student ID. Please enter a number.");
        }
    }

    // Method to display the list of students in JTextArea
    private static void hienThiDanhSach() {
        StringBuilder sb = new StringBuilder();
        for (Student student : students) {
            sb.append(student.toString()).append("\n");
        }
        txtAreaDanhSach.setText(sb.toString());
    }

    // Method to save the list of students to a file
    private static void luuDanhSachVaoFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.dat"))) {
            oos.writeObject(students);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to read the list of students from a file
    private static void docDanhSachTuFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.dat"))) {
            students = (List<Student>) ois.readObject();
            hienThiDanhSach();
        } catch (FileNotFoundException e) {
            // File not found, no action needed
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Inner class for Student
    static class Student implements Serializable {
        private int maSV;
        private String tenSV;

        public Student(int maSV, String tenSV) {
            this.maSV = maSV;
            this.tenSV = tenSV;
        }

        public int getMaSV() {
            return maSV;
        }

        public void setTenSV(String tenSV) {
            this.tenSV = tenSV;
        }

        @Override
        public String toString() {
            return "ID: " + maSV + ", Name: " + tenSV;
        }
    }
}
